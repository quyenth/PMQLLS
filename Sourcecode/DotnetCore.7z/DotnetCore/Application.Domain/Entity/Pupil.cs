﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Domain.Entity
{
    public class Pupil
    {
        public int PupilID { get; set; }
        public string PupilName { get; set; }
        public string ClassName { get; set; }
    }
}
